<?php

namespace App\Provider\Command;


use App\Components\Configure;
use App\Http\Models\User;
use App\Helpers\Hash;
use App\Helpers\Tools;
use Exception;
use Ramsey\Uuid\Uuid;
use App\Http\Models\Rates;
use AlphaVantage;


class XCat
{
    public $argv;

    public function __construct($argv)
    {
        $this->argv = $argv;
    }
	

    public function boot()
    {
		switch ($this->argv[1]) {
			case ('dailyjob'):
                return (new Job())->DailyJob();
			case ('upgrade'):
                return (new Upgrade())->xmanager_upgrade();	
            case ('checkjob'):
                return (new Job())->CheckJob();	
			case ('onlineip'):
                return (new Job())->OnlineIPs();		
			case ('downloadApps'):
                return (new Clients())->boot();	
			case ('createAdmin'):
                return self::createAdmin();
            case ('resetTraffic'):
                return self::resetTraffic();
			case ('resetdailytraffic'):
                return self::resetLastTraffic();	
            case ('setTelegram'):
                return self::setTelegram();
			case ('backup'):
                return (new Backup())->backup(true);
			case ('update'):
                return (new CheckUpdate())->Update();
			case ('autocheck'):
                return (new CheckUpdate())->versioncheck();
			case ('getCookie'):
                return self::getCookie();
			case ('onlineips'):
                return (new Job())->OnlineUserIP();	
			default:
                return self::defaultAction();	
		}	
	}

	
	public function defaultAction()
    {
		echo (PHP_EOL . 'Usage： php cronjob [Options]' . PHP_EOL);
        echo ('Options:' . PHP_EOL);
		echo ('======================================================' . PHP_EOL);
        echo ('createAdmin          - Create an Administrator account' . PHP_EOL);
        echo ('setTelegram          - Set Telegram bot' . PHP_EOL);
        echo ('resetTraffic         - Reset all user traffic' . PHP_EOL);
		echo ('rate                 - Exchange Rate' . PHP_EOL);
		echo ('downloadApps         - Download Apps' . PHP_EOL);
		echo ('backup               - Backup Database' . PHP_EOL);
		echo ('checkjob             - Execute minute cron job' . PHP_EOL);
		echo ('dailyjob             - Execute Daily cron job' . PHP_EOL);
		echo ('resetTraffic         - Rset all users used data(traffic) to zero(0)GB' . PHP_EOL);
		echo ('autocheck            - Check For Xmanager Updates ' . PHP_EOL);
		echo ('update               - Update Xmanager' . PHP_EOL);
		echo ('resetdailytraffic    - Reset daily used trafic' . PHP_EOL);
		echo ('onlineip             - Disconnect Ips' . PHP_EOL);
		echo ('======================================================' . PHP_EOL);
	}


	
	public function rate()
	{	
		$Config = new Configure();
		if($Config->getConfig('alphavantage_apikey')){
			$option = new AlphaVantage\Options();
			$option->setApiKey($Config->getConfig('alphavantage_apikey'));
			$client = new AlphaVantage\Client($option);
			$obj = $client->foreignExchange()->currencyExchangeRate('USD', 'CNY');
			$result =$obj['Realtime Currency Exchange Rate']['5. Exchange Rate'];
			$rate = round($result, 2);
			if($rate){
				$Config->setConfig('rate', $rate); 
			}
			echo $rate . PHP_EOL;
		}else{
			echo "AlphaVantage Apikey required". PHP_EOL;
		}
	}
	

	
    public function resetTraffic()
    {
        try {
            User::where('enable', 1)->update([
                'd'          => 0,
                'u'          => 0,
                'last_day_t' => 0,
            ]);
        } catch (Exception $e) {
            echo $e->getMessage();
            return;
        }
        echo 'reset traffic successful' . PHP_EOL;
    }



    public static function resetLastTraffic()
    {
        $users = User::all();
        foreach ($users as $user) {
            $user->last_day_t=($user->u+$user->d);
            $user->save();
        }
    }

    public function createAdmin()
    {
		$Config = new Configure();
        if (count($this->argv) === 2) {
            echo 'create admin.....'. PHP_EOL;
            fwrite(STDOUT, 'Enter your email: ');       
            $email = trim(fgets(STDIN));
            fwrite(STDOUT, "Enter password for: $email: ");
            $passwd = trim(fgets(STDIN));
            echo "Email: $email, Password: $passwd! ";
            fwrite(STDOUT, "Press [y] to create admin.....". PHP_EOL);
            $y = trim(fgets(STDIN));
        } elseif (count($this->argv) === 4) {
            [,, $email, $passwd] = $this->argv;
            $y = 'y';
        }

        if (strtolower($y) == 'y') {
            echo 'start create admin account'. PHP_EOL;
            
            $user                   = new User();
            $user->user_name        = 'admin';
            $user->email            = $email;
            $user->pass             = Hash::passwordHash($passwd);
            $user->passwd           = Tools::genRandomChar(6);
            $user->afflink          = Tools::genRandomChar(10);
			$user->uuid          	= Uuid::uuid3(Uuid::NAMESPACE_DNS,$user->email . '|' . $user->passwd);
            $user->t                = 0;
            $user->u                = 0;
            $user->d                = 0;
            $user->transfer_enable  = Tools::toGB((int) $Config->getConfig('reg_traffic'));
            $user->ref_by           = 0;
            $user->is_admin         = 1;
            $user->expire_in        = date('Y-m-d H:i:s', time() + (int) $Config->getConfig('reg_traffic_exp') * 86400);
            $user->reg_date         = date('Y-m-d H:i:s');
            $user->money            = 0;
            $user->class            = 0;
            $user->node_speedlimit  = $Config->getConfig('reg_speed');
			$user->node_group  		= 0;
			$user->node_connector  	= $Config->getConfig('reg_connector');

            if ($user->save()) {
                echo 'Successful' . PHP_EOL;
            } else {
                echo 'error' . PHP_EOL;
            }
        } else {
            echo 'cancel' . PHP_EOL;
        }
    }
	
	
	

    public function setTelegram()
    {
		$Config = new Configure();
		$bot_api_key  = $Config->getConfig('telegram_token');
		$bot_username = $Config->getConfig('telegram_bot');
		$hook_url     = $Config->getConfig('baseUrl') . '/telegram_callback?token=' . $Config->getConfig('telegram_request_token');
		try {
			$telegram = new \Longman\TelegramBot\Telegram($bot_api_key, $bot_username);
			$telegram->deleteWebhook();
			$result = $telegram->setWebhook($hook_url);
			if ($result->isOk()) {
				echo $result->getDescription(). PHP_EOL ;
			}
		} catch (Longman\TelegramBot\Exception\TelegramException $e) {
			 echo $e->getMessage();
		}

     }

	
	
    public function getCookie()
    {
        if (count($this->argv) === 3) {
            $user = User::find($this->argv[2]);
            $expire_in = 86400 + time();
            echo Hash::cookieHash($user->pass, $expire_in) . ' ' . $expire_in;
        }
    }
}	