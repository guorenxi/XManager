
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


CREATE TABLE IF NOT EXISTS `payout` (
  `id` int(12) NOT NULL,
  `userid` int(12) NOT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `account` varchar(250) CHARACTER SET utf8 DEFAULT NULL,
  `method` int(5) NOT NULL DEFAULT '1',
  `status` int(11) DEFAULT NULL,
  `datetime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `payout`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `payout`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT;

