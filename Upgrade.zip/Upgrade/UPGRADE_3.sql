ALTER TABLE `package` DROP  COLUMN `content`;
ALTER TABLE `package` DROP  COLUMN `category`;
ALTER TABLE `package` DROP  COLUMN `price`;
ALTER TABLE `package` DROP  COLUMN `expire_days`;
ALTER TABLE `package` DROP  COLUMN `allow_buy_count`;
